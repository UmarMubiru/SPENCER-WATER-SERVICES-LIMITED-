from django.apps import AppConfig


class InventoryConfig(AppConfig):

    default_auto_field = (
        "django.db.models.BigAutoField"
    )

    name = "inventory"

    verbose_name = (
        "Inventory Management"
    )

    def ready(self):
        pass
        #import inventory.signals